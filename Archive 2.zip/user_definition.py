# https://developers.google.com/maps/documentation/javascript/get-api-key
apikey = "AIzaSyCSX1AjP3IMYq9CsrjiAh5RqlFyBd5uJW8"
orig_coord = '37.7909,-122.3925'
dest_coord = '37.7765,-122.4506'
output_file = 'time.tsv'
bucket_name="msds694"
